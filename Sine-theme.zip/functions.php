<?php

wp_enqueue_style('style',get_stylesheet_uri(),NULL, microtime() );

?>