<div class="col-md-4 content-left">
					<div class="insights backgroun1 pad30 ">
						<div class="row">
							<div class="col-md-5"><img src="<?php bloginfo('template_url'); ?>/assets/images/Location.png"></div>
							<div class="col-md-7">Location <br> <strong>Brisbane, SA</strong></div>
						</div>
						<div class="row">
							<div class="col-md-5"><img src="<?php bloginfo('template_url'); ?>/assets/images/Industry.png"></div>
							<div class="col-md-7">Industry <br> <strong>Government</strong></div>
						</div>
						<div class="row">
							<div class="col-md-5"><img src="<?php bloginfo('template_url'); ?>/assets/images/Hosts.png"></div>
							<div class="col-md-7">Hosts <br> <strong>3,500</strong></div>
						</div>
						<div class="row">
							<div class="col-md-5"><img src="<?php bloginfo('template_url'); ?>/assets/images/Visitors.png"></div>
							<div class="col-md-7">Visitors <br> <strong>2,300</strong></div>
						</div>
						<div class="row">
							<div class="col-md-5"><img src="<?php bloginfo('template_url'); ?>/assets/images/iPads.png"></div>
							<div class="col-md-7">iPads <br> <strong>7</strong></div>
						</div>
					</div>
					<div class="company backgroun1 pad30 martop30">
						<h4>Company</h4>
						<p>Local government body with over 175 staff members and elected officials. </p>
						<hr>
						<p>Visitors include local residents and groups, government partners, and council workers.</p>
						<hr>
					</div>
					<div class="benefits backgroun1 pad30 martop30">
						<h4>Benefits</h4>
						
						<p>Remote viewing of who is onsite – accounting for visitors & contractors during evacuation via mobile.</p>
						<hr>


					</div>
				</div>