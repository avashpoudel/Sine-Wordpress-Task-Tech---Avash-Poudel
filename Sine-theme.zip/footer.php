<footer>
		<div class="container">
			<h1>Try Sine today</h1>
			<div class="newsletter">
				<input type="text" name="" placeholder="Enter your business email" />
				<input type="button" name="" value="Get started" />
			</div>
			<p>Try Sine for 30 days, no credit card required.</p>
		</div>
	</footer>
<?php wp_footer(); ?> 
</body>
</html>